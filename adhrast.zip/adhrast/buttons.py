from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup
AdFast = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="AdFast", callback_data="fast")
        ]
    ]
)
Menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Добавить человека/канал", callback_data="add_us"),
            InlineKeyboardButton(text="Посмотреть список", callback_data="check_list")
        ]
    ]
)
cancel = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Отмена", callback_data="cancel")
        ]
    ]
)
