
from buttons import AdFast, Menu, cancel
import sqlite3
import re
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor, callback_data
class Mydialog(StatesGroup):
    otvet = State()

TOKEN = "6187821279:AAFFslSjAJFy2SXPCfwZcdvsU5If8xcwgEg"

bot = Bot(token=TOKEN)

dp = Dispatcher(bot, storage=MemoryStorage())

@dp.message_handler(commands=['start'])
async def start_message(message: types.Message):
    username = message.from_user.username
    await bot.send_message(message.chat.id,f"Здравствуйте @{username}, это виртуальный помощник компании CWS для администраторов, выберите проект в котором вы администратор⬇️", reply_markup=AdFast)


@dp.callback_query_handler(text="fast")
async def main_menu(callback: types.CallbackQuery):
    await callback.message.answer("Выберите дальнейшее действие:",reply_markup=Menu)

@dp.callback_query_handler(text="add_us")
async def cmd_dialog(callback: types.CallbackQuery):
    await Mydialog.otvet.set()  # вот мы указали начало работы состояний (states)
    await callback.message.answer("""Для добавления человека/канала напишите: ссылка на человека - ссылка на канал. 
Пример: @radikaiifo - @AdFost
Можно составлять список из несколько человек/каналов.
Пример: @radikaiifo - @AdFost
@cws_admln - @ot_kayfa""")


@dp.message_handler(state=Mydialog.otvet)
async def process_message(message: types.Message, state: FSMContext):

    async with state.proxy() as data:
        data['text'] = message.text
        user_message = data['text']
    await state.finish()
    if user_message.lower() == "отмена":


        await bot.send_message(message.chat.id, "Выберите дальнейшее действие:", reply_markup=Menu)
    else:
        file = open(file='basa.txt', mode='a', encoding='utf-8'  )

        file.write(user_message + '\n')
        file.close()

        await message.answer("Пользователь/канал добавлен успешно!", reply_markup=Menu)

@dp.callback_query_handler(text="check_list")
async def listener(callback: types.CallbackQuery):
    try:
        file = open(file='basa.txt', mode='r', encoding='utf-8')

        vp = file.read()
        file.close()
        await callback.message.answer(vp, reply_markup=Menu)
    except BaseException:
        await callback.message.answer("Список пуст!", reply_markup=Menu)




@dp.callback_query_handler(text="cancel")
async def main_menu(callback: types.CallbackQuery):
    username = callback.from_user.username
    await callback.message.answer(f"Здравствуйте @{username}, это виртуальный помощник компании CWS для администраторов, выберите проект в котором вы администратор⬇️", reply_markup=AdFast)


if __name__ == '__main__':

    executor.start_polling(dp, skip_updates=True)